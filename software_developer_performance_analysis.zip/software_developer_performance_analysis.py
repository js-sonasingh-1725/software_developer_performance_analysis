"""
╔══════════════════════════════════════════════════════════════════════╗
║       SOFTWARE DEVELOPER PERFORMANCE ANALYSIS SYSTEM                ║
║       Complete single-file project — Python 3.10+                   ║
║                                                                      ║
║  Usage:                                                              ║
║    python main.py generate   --devs 20 --weeks 52                   ║
║    python main.py analyze    --input data/sample_data.csv --export  ║
║    python main.py visualize  --input data/sample_data.csv           ║
║    python main.py full       --devs 20 --weeks 52                   ║
╚══════════════════════════════════════════════════════════════════════╝

Install dependencies first:
    pip install numpy pandas scipy matplotlib seaborn
"""

# ═══════════════════════════════════════════════════════════════════════
# STDLIB IMPORTS
# ═══════════════════════════════════════════════════════════════════════
from __future__ import annotations

import argparse
import logging
import sys
import warnings
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

# ═══════════════════════════════════════════════════════════════════════
# THIRD-PARTY IMPORTS
# ═══════════════════════════════════════════════════════════════════════
try:
    import numpy as np
    import pandas as pd
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.gridspec as gridspec
    import matplotlib.patches as mpatches
    import seaborn as sns
    from scipy import stats
except ImportError as e:
    print(f"[ERROR] Missing dependency: {e}")
    print("Run:  pip install numpy pandas scipy matplotlib seaborn")
    sys.exit(1)

warnings.filterwarnings("ignore", category=RuntimeWarning)


# ═══════════════════════════════════════════════════════════════════════
# ── MODULE 1: LOGGER ──────────────────────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════

def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """Return a configured logger with a clean format."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(
            "%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
            datefmt="%H:%M:%S",
        ))
        logger.addHandler(handler)
    logger.setLevel(level)
    return logger


log = get_logger("devperf")


# ═══════════════════════════════════════════════════════════════════════
# ── MODULE 2: DATA GENERATOR ──────────────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════

DEVELOPER_ROLES  = ["Junior", "Mid", "Senior", "Lead", "Principal"]
TEAMS            = ["Backend", "Frontend", "DevOps", "Data", "Mobile"]

ROLE_MULTIPLIERS = {
    "Junior":    {"commits": 0.6, "prs": 0.5, "reviews": 0.3, "bugs": 1.4, "velocity": 0.6},
    "Mid":       {"commits": 1.0, "prs": 1.0, "reviews": 0.8, "bugs": 1.0, "velocity": 1.0},
    "Senior":    {"commits": 1.2, "prs": 1.3, "reviews": 1.5, "bugs": 0.7, "velocity": 1.3},
    "Lead":      {"commits": 0.9, "prs": 1.1, "reviews": 2.0, "bugs": 0.5, "velocity": 1.2},
    "Principal": {"commits": 0.7, "prs": 0.8, "reviews": 2.5, "bugs": 0.4, "velocity": 1.4},
}

BASE_METRICS = {
    "commits_per_week":         12,
    "prs_opened":                3,
    "prs_merged":                2.5,
    "code_review_comments":      8,
    "bugs_introduced":           1.5,
    "bugs_fixed":                2.0,
    "story_points_completed":   15,
    "lines_added":             400,
    "lines_removed":           200,
    "test_coverage_pct":        72,
    "build_success_rate":        0.88,
    "deployment_frequency":      1.5,
    "mean_pr_cycle_time_hours": 18,
    "on_call_incidents":         0.4,
    "documentation_updates":     1.2,
}


class DataGenerator:
    """
    Generates realistic synthetic developer performance data.

    Each developer gets:
      - A role-based productivity multiplier
      - A personal skill factor (Gaussian noise around 1.0)
      - A seasonal productivity wave (sin curve over 52 weeks)
      - A burnout/ramp-up trend applied after week 20
    """

    def __init__(self, seed: int = 42):
        self.rng = np.random.default_rng(seed)

    # ── Public ─────────────────────────────────────────────────────────

    def generate(
        self,
        n_developers: int = 10,
        n_weeks: int = 26,
        output_path: str = "data/sample_data.csv",
    ) -> pd.DataFrame:
        """Generate and persist the dataset. Returns the DataFrame."""
        developers = self._create_developer_profiles(n_developers)
        weeks      = pd.date_range(end=pd.Timestamp.today(), periods=n_weeks, freq="W-MON")
        records    = [
            self._generate_weekly_record(dev, idx, date, n_weeks)
            for dev in developers
            for idx, date in enumerate(weeks)
        ]
        df = pd.DataFrame(records)
        df = self._add_derived_metrics(df)

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False)
        log.info(f"Generated {len(df)} rows ({n_developers} devs × {n_weeks} weeks) → {output_path}")
        return df

    # ── Private ────────────────────────────────────────────────────────

    def _create_developer_profiles(self, n: int) -> list[dict]:
        return [
            {
                "developer_id": f"DEV{i+1:03d}",
                "name":         f"Developer_{i+1}",
                "role":         str(self.rng.choice(
                    DEVELOPER_ROLES, p=[0.20, 0.35, 0.25, 0.12, 0.08]
                )),
                "team":         str(self.rng.choice(TEAMS)),
                "seniority_years": self._role_to_years(
                    str(self.rng.choice(DEVELOPER_ROLES, p=[0.20, 0.35, 0.25, 0.12, 0.08]))
                ),
                "skill_factor": float(self.rng.normal(1.0, 0.12)),
            }
            for i in range(n)
        ]

    def _role_to_years(self, role: str) -> float:
        ranges = {
            "Junior": (0.5, 2), "Mid": (2, 5), "Senior": (5, 10),
            "Lead": (8, 15),    "Principal": (12, 20),
        }
        lo, hi = ranges[role]
        return round(float(self.rng.uniform(lo, hi)), 1)

    def _generate_weekly_record(
        self, dev: dict, week_idx: int,
        week_date: pd.Timestamp, total_weeks: int
    ) -> dict:
        rm = ROLE_MULTIPLIERS[dev["role"]]
        sf = dev["skill_factor"]

        # Seasonal wave — peaks mid-year
        season = 1 + 0.15 * np.sin(2 * np.pi * week_idx / 52)

        # Burnout trend — productivity dips after week 20
        trend = 1.0 if week_idx < 20 else max(0.75, 1.0 - 0.008 * (week_idx - 20))

        def metric(key: str, noise: float = 0.25) -> float:
            base  = BASE_METRICS[key]
            mul   = rm.get(key.split("_")[0], 1.0)
            raw   = base * mul * sf * season * trend
            noisy = raw * (1 + self.rng.normal(0, noise))
            return max(0.0, round(float(noisy), 2))

        commits         = max(0, int(metric("commits_per_week")))
        prs_opened      = max(0, int(metric("prs_opened")))
        prs_merged      = max(0, min(prs_opened, int(metric("prs_merged"))))
        review_comments = max(0, int(metric("code_review_comments")))
        bugs_intro      = max(0, int(metric("bugs_introduced")))
        bugs_fixed      = max(0, int(metric("bugs_fixed")))
        story_pts       = max(0, int(metric("story_points_completed")))
        lines_added     = max(0, int(metric("lines_added")))
        lines_removed   = max(0, int(metric("lines_removed")))
        test_cov        = min(100.0, max(0.0, metric("test_coverage_pct",        0.05)))
        build_sr        = min(1.0,   max(0.0, metric("build_success_rate",        0.08)))
        deploy_freq     = max(0.0,            metric("deployment_frequency",      0.30))
        pr_cycle_hrs    = max(1.0,            metric("mean_pr_cycle_time_hours",  0.35))
        incidents       = max(0, int(metric("on_call_incidents", 0.50)))
        doc_updates     = max(0, int(metric("documentation_updates", 0.40)))

        return {
            "developer_id":          dev["developer_id"],
            "name":                  dev["name"],
            "role":                  dev["role"],
            "team":                  dev["team"],
            "seniority_years":       dev["seniority_years"],
            "week_start":            week_date.date().isoformat(),
            "commits":               commits,
            "prs_opened":            prs_opened,
            "prs_merged":            prs_merged,
            "code_review_comments":  review_comments,
            "bugs_introduced":       bugs_intro,
            "bugs_fixed":            bugs_fixed,
            "story_points":          story_pts,
            "lines_added":           lines_added,
            "lines_removed":         lines_removed,
            "test_coverage_pct":     round(test_cov, 1),
            "build_success_rate":    round(build_sr, 3),
            "deployment_frequency":  round(deploy_freq, 2),
            "pr_cycle_time_hours":   round(pr_cycle_hrs, 1),
            "on_call_incidents":     incidents,
            "documentation_updates": doc_updates,
        }

    @staticmethod
    def _add_derived_metrics(df: pd.DataFrame) -> pd.DataFrame:
        df["pr_merge_rate"] = (
            df["prs_merged"] / df["prs_opened"].replace(0, np.nan)
        ).fillna(0).round(3)
        df["bug_fix_ratio"] = (
            df["bugs_fixed"] / df["bugs_introduced"].replace(0, np.nan)
        ).fillna(0).round(3)
        df["churn_ratio"] = (
            df["lines_removed"]
            / (df["lines_added"] + df["lines_removed"]).replace(0, np.nan)
        ).fillna(0).round(3)
        return df


# ═══════════════════════════════════════════════════════════════════════
# ── MODULE 3: ANALYSIS ENGINE ─────────────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════

# Weighted scoring dimensions (must sum to 1.0)
SCORE_WEIGHTS = {
    "output_score":        0.25,
    "quality_score":       0.30,
    "collaboration_score": 0.20,
    "delivery_score":      0.15,
    "reliability_score":   0.10,
}

PERFORMANCE_BANDS = {
    "Elite":      (90, 100),
    "Strong":     (75,  90),
    "Adequate":   (55,  75),
    "Developing": (35,  55),
    "At Risk":    ( 0,  35),
}


@dataclass
class AnalysisResults:
    """Container for all analysis outputs."""
    raw_df:       pd.DataFrame
    weekly_df:    pd.DataFrame    # per-row scores
    summary:      pd.DataFrame    # one row per developer
    trends:       pd.DataFrame    # linear trend per developer
    anomalies:    pd.DataFrame    # z-score outlier weeks
    correlations: pd.DataFrame    # metric correlation matrix
    team_summary: pd.DataFrame    # team aggregation
    metadata:     dict = field(default_factory=dict)


class PerformanceEngine:
    """
    Multi-dimensional scoring, trend detection, and anomaly flagging.

    Scoring pipeline:
      1. Percentile-scale each raw metric group → 0-100 sub-score
      2. Weighted sum → composite score
      3. Assign performance band
      4. Run scipy linregress per developer → trend / significance
      5. Flag weekly z-score outliers
    """

    def __init__(self, data_path: str = "data/sample_data.csv"):
        self.data_path = data_path
        self.df: pd.DataFrame | None = None

    # ── Public ─────────────────────────────────────────────────────────

    def run_full_analysis(self) -> AnalysisResults:
        self._load()
        weekly_df    = self._compute_weekly_scores()
        summary      = self._build_developer_summary(weekly_df)
        trends       = self._detect_trends(weekly_df)
        anomalies    = self._detect_anomalies(weekly_df)
        correlations = self._compute_correlations()
        team_summary = self._team_summary(summary)

        results = AnalysisResults(
            raw_df=self.df,
            weekly_df=weekly_df,
            summary=summary,
            trends=trends,
            anomalies=anomalies,
            correlations=correlations,
            team_summary=team_summary,
            metadata={
                "data_path":    self.data_path,
                "n_developers": self.df["developer_id"].nunique(),
                "n_weeks":      self.df["week_start"].nunique(),
                "date_range":  (self.df["week_start"].min(), self.df["week_start"].max()),
            },
        )
        log.info(
            f"Analysis complete — {results.metadata['n_developers']} developers, "
            f"{results.metadata['n_weeks']} weeks"
        )
        return results

    # ── Private: Loading ───────────────────────────────────────────────

    def _load(self):
        self.df = pd.read_csv(self.data_path, parse_dates=["week_start"])
        log.info(f"Loaded {len(self.df)} rows from {self.data_path}")

    # ── Private: Scoring ───────────────────────────────────────────────

    def _compute_weekly_scores(self) -> pd.DataFrame:
        df = self.df.copy()

        # Output — throughput
        df["output_score"] = self._pscale(
            df["commits"] * 0.4 + df["story_points"] * 0.6
        )
        # Quality — coverage + build health + bug hygiene
        df["quality_score"] = self._pscale(
            df["test_coverage_pct"]          * 0.35
            + df["build_success_rate"] * 100 * 0.35
            + df["bug_fix_ratio"].clip(0, 3) / 3 * 100 * 0.30
            - df["bugs_introduced"] * 2              # penalty
        )
        # Collaboration — reviews, merge rate, docs
        df["collaboration_score"] = self._pscale(
            df["code_review_comments"] * 0.40
            + df["pr_merge_rate"] * 100  * 0.35
            + df["documentation_updates"] * 5 * 0.25
        )
        # Delivery — story points + deploy cadence
        df["delivery_score"] = self._pscale(
            df["story_points"]          * 0.50
            + df["deployment_frequency"] * 10 * 0.50
        )
        # Reliability — low incidents + fast PR cycle
        df["reliability_score"] = self._pscale(
            -df["on_call_incidents"]     * 10
            - df["pr_cycle_time_hours"]
        )

        df["composite_score"] = sum(
            df[dim] * w for dim, w in SCORE_WEIGHTS.items()
        ).round(2)

        df["performance_band"] = df["composite_score"].apply(self._band)
        return df

    # ── Private: Developer summary ─────────────────────────────────────

    def _build_developer_summary(self, weekly_df: pd.DataFrame) -> pd.DataFrame:
        score_cols = [
            "output_score", "quality_score", "collaboration_score",
            "delivery_score", "reliability_score", "composite_score",
        ]
        raw_cols = [
            "commits", "story_points", "bugs_introduced", "bugs_fixed",
            "test_coverage_pct", "build_success_rate", "code_review_comments",
        ]
        grp  = weekly_df.groupby(["developer_id", "name", "role", "team"])
        agg  = grp[score_cols].mean().round(2)
        ragg = grp[raw_cols].mean().round(2)

        agg["percentile_rank"]  = agg["composite_score"].rank(pct=True).mul(100).round(1)
        agg["performance_band"] = agg["composite_score"].apply(self._band)

        summary = pd.concat([agg, ragg], axis=1).reset_index()
        return summary.sort_values("composite_score", ascending=False).reset_index(drop=True)

    # ── Private: Trend detection ───────────────────────────────────────

    def _detect_trends(self, weekly_df: pd.DataFrame) -> pd.DataFrame:
        records = []
        for dev_id, grp in weekly_df.groupby("developer_id"):
            g = grp.sort_values("week_start")
            x = np.arange(len(g), dtype=float)
            y = g["composite_score"].values
            if len(x) < 3:
                continue
            slope, _, r, p, _ = stats.linregress(x, y)
            records.append({
                "developer_id":   dev_id,
                "name":           g["name"].iloc[0],
                "role":           g["role"].iloc[0],
                "slope_per_week": round(slope, 4),
                "r_squared":      round(r ** 2, 4),
                "p_value":        round(p, 4),
                "significant":    p < 0.05,
                "trend": (
                    "Improving" if slope > 0.1
                    else ("Declining" if slope < -0.1 else "Stable")
                ),
            })
        return pd.DataFrame(records).sort_values("slope_per_week", ascending=False)

    # ── Private: Anomaly detection ─────────────────────────────────────

    def _detect_anomalies(self, weekly_df: pd.DataFrame, z_thresh: float = 2.5) -> pd.DataFrame:
        parts = []
        for _, grp in weekly_df.groupby("developer_id"):
            s = grp["composite_score"]
            if s.std() == 0:
                continue
            z    = np.abs(stats.zscore(s))
            flag = grp[z > z_thresh].copy()
            if flag.empty:
                continue
            flag["z_score"]     = z[z > z_thresh].round(3)
            flag["anomaly_type"] = np.where(
                flag["composite_score"] > s.mean(), "Positive spike", "Negative dip"
            )
            parts.append(flag[["developer_id", "name", "week_start",
                                "composite_score", "z_score", "anomaly_type"]])
        if parts:
            return pd.concat(parts).sort_values("z_score", ascending=False).reset_index(drop=True)
        return pd.DataFrame()

    # ── Private: Correlations ──────────────────────────────────────────

    def _compute_correlations(self) -> pd.DataFrame:
        cols = [
            "commits", "story_points", "code_review_comments",
            "bugs_introduced", "bugs_fixed", "test_coverage_pct",
            "build_success_rate", "deployment_frequency",
            "pr_cycle_time_hours", "on_call_incidents",
        ]
        return self.df[cols].corr().round(3)

    # ── Private: Team aggregation ──────────────────────────────────────

    def _team_summary(self, summary: pd.DataFrame) -> pd.DataFrame:
        agg = summary.groupby("team").agg(
            n_developers   = ("developer_id",     "count"),
            avg_composite  = ("composite_score",  "mean"),
            avg_quality    = ("quality_score",    "mean"),
            avg_collab     = ("collaboration_score", "mean"),
            avg_bugs       = ("bugs_introduced",  "mean"),
            avg_coverage   = ("test_coverage_pct","mean"),
        ).round(2).reset_index()
        return agg.sort_values("avg_composite", ascending=False)

    # ── Utilities ──────────────────────────────────────────────────────

    @staticmethod
    def _pscale(s: pd.Series) -> pd.Series:
        """Percentile-clip → min-max scale → 0-100."""
        lo, hi = s.quantile(0.02), s.quantile(0.98)
        return ((s.clip(lo, hi) - lo) / (hi - lo + 1e-9) * 100).clip(0, 100).round(2)

    @staticmethod
    def _band(score: float) -> str:
        for band, (lo, hi) in PERFORMANCE_BANDS.items():
            if lo <= score <= hi:
                return band
        return "Unknown"


# ═══════════════════════════════════════════════════════════════════════
# ── MODULE 4: DASHBOARD ───────────────────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════

# Dark theme colours
_BG     = "#0F1117"
_FG     = "#E8EAF0"
_GRID   = "#2A2D3A"
_ACCENT = "#5B8CFF"
_ROSE   = "#FF6B9D"

BAND_COLORS = {
    "Elite":      "#2ECC71",
    "Strong":     "#27AE60",
    "Adequate":   "#F39C12",
    "Developing": "#E67E22",
    "At Risk":    "#E74C3C",
}


def _apply_dark_theme():
    plt.rcParams.update({
        "figure.facecolor": _BG, "axes.facecolor":  _BG,
        "axes.edgecolor":  _GRID, "axes.labelcolor": _FG,
        "axes.titlecolor": _FG,   "xtick.color":     _FG,
        "ytick.color":     _FG,   "text.color":      _FG,
        "grid.color":      _GRID, "grid.linestyle":  "--",
        "grid.linewidth":  0.5,   "legend.facecolor":"#1A1D26",
        "legend.edgecolor":_GRID, "font.family":     "DejaVu Sans",
        "font.size":       9,
    })


class Dashboard:
    """
    8-panel Matplotlib dashboard covering:
      1. Top performers bar chart
      2. Performance band donut
      3. Team radar (spider)
      4. Weekly trend lines
      5. Metric correlation heatmap
      6. Stacked score breakdown
      7. Trend slope scatter
      8. Anomaly timeline
    """

    def __init__(self, results: AnalysisResults):
        self.r = results

    def render(self, save_path: str = "visualizations/dashboard.png",
               show: bool = False, dpi: int = 150):
        if show:
            matplotlib.use("TkAgg")

        _apply_dark_theme()
        fig = plt.figure(figsize=(20, 14), facecolor=_BG)
        fig.suptitle(
            "Software Developer Performance Analysis Dashboard",
            fontsize=18, fontweight="bold", color=_FG, y=0.98,
        )
        gs = gridspec.GridSpec(
            3, 4, figure=fig,
            hspace=0.45, wspace=0.35,
            left=0.06, right=0.97, top=0.93, bottom=0.06,
        )

        self._top_performers(fig.add_subplot(gs[0, :2]))
        self._band_donut(fig.add_subplot(gs[0, 2]))
        self._team_radar(fig.add_subplot(gs[0, 3]))
        self._score_trend(fig.add_subplot(gs[1, :2]))
        self._corr_heatmap(fig.add_subplot(gs[1, 2:]))
        self._score_breakdown(fig.add_subplot(gs[2, :2]))
        self._trend_scatter(fig.add_subplot(gs[2, 2]))
        self._anomaly_timeline(fig.add_subplot(gs[2, 3]))

        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=dpi, bbox_inches="tight", facecolor=_BG)
        log.info(f"Dashboard saved → {save_path}")
        if show:
            plt.show()
        plt.close(fig)

    # ── Panels ─────────────────────────────────────────────────────────

    def _top_performers(self, ax):
        top    = self.r.summary.head(10)
        colors = [BAND_COLORS.get(b, _ACCENT) for b in top["performance_band"]]
        bars   = ax.barh(top["name"], top["composite_score"], color=colors,
                         edgecolor="none", height=0.65)
        ax.set_xlim(0, 108)
        ax.set_xlabel("Composite Score")
        ax.set_title("Top 10 Developers — Composite Score", fontweight="bold")
        ax.invert_yaxis()
        ax.axvline(top["composite_score"].mean(), color=_ROSE, linestyle="--",
                   linewidth=1, label="Mean")
        for bar, (_, row) in zip(bars, top.iterrows()):
            ax.text(bar.get_width() + 1, bar.get_y() + bar.get_height() / 2,
                    f"{row['composite_score']:.1f}  [{row['role']}]",
                    va="center", fontsize=7.5, color=_FG)
        ax.legend(fontsize=8)
        ax.grid(axis="x", alpha=0.4)

    def _band_donut(self, ax):
        bands     = self.r.summary["performance_band"].value_counts()
        band_ord  = [b for b in PERFORMANCE_BANDS if b in bands.index]
        bands     = bands.reindex(band_ord)
        colors    = [BAND_COLORS[b] for b in bands.index]
        _, texts, autotexts = ax.pie(
            bands.values, labels=bands.index, colors=colors,
            autopct="%1.0f%%", startangle=90, pctdistance=0.75,
            wedgeprops={"width": 0.55, "edgecolor": _BG, "linewidth": 2},
        )
        for t in texts:
            t.set_color(_FG); t.set_fontsize(8)
        for at in autotexts:
            at.set_color(_BG); at.set_fontsize(8); at.set_fontweight("bold")
        ax.set_title("Performance Band Distribution", fontweight="bold")

    def _team_radar(self, ax):
        team_df = self.r.team_summary
        metrics = ["avg_composite", "avg_quality", "avg_collab", "avg_bugs", "avg_coverage"]
        labels  = ["Composite", "Quality", "Collab", "Bugs↓", "Coverage"]
        N       = len(metrics)
        angles  = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist() + [0]

        ax = plt.subplot(ax.get_subplotspec(), polar=True)
        ax.set_facecolor(_BG)
        ax.set_theta_offset(np.pi / 2)
        ax.set_theta_direction(-1)
        ax.set_thetagrids(np.degrees(angles[:-1]), labels, fontsize=8, color=_FG)
        ax.tick_params(colors=_FG)
        ax.yaxis.set_tick_params(labelcolor="none")

        for (_, row), col in zip(team_df.iterrows(), plt.cm.tab10(np.linspace(0, 1, len(team_df)))):
            vals = [row[m] for m in metrics]
            vals[3] = max(0, 100 - vals[3] * 10)   # invert bug count
            vals += vals[:1]
            ax.plot(angles, vals, color=col, linewidth=1.5, label=row["team"])
            ax.fill(angles, vals, color=col, alpha=0.08)

        ax.set_title("Team Radar", fontweight="bold", pad=12)
        ax.legend(loc="upper right", bbox_to_anchor=(1.4, 1.12), fontsize=7)

    def _score_trend(self, ax):
        top5   = self.r.summary.head(5)["developer_id"].tolist()
        colors = plt.cm.tab10(np.linspace(0, 1, 5))
        for dev_id, col in zip(top5, colors):
            grp  = self.r.weekly_df[self.r.weekly_df["developer_id"] == dev_id]
            grp  = grp.sort_values("week_start")
            roll = grp["composite_score"].rolling(3, min_periods=1).mean()
            ax.plot(grp["week_start"], grp["composite_score"],
                    color=col, linewidth=1.2, alpha=0.5, label=grp["name"].iloc[0])
            ax.plot(grp["week_start"], roll, color=col, linewidth=2.5)
        ax.set_title("Weekly Composite Score — Top 5 (3-wk rolling)", fontweight="bold")
        ax.set_xlabel("Week")
        ax.set_ylabel("Composite Score")
        ax.legend(fontsize=8, ncol=2)
        ax.grid(True, alpha=0.3)

    def _corr_heatmap(self, ax):
        short = {
            "commits": "Commits", "story_points": "StoryPts",
            "code_review_comments": "Reviews", "bugs_introduced": "BugsIn",
            "bugs_fixed": "BugsFix", "test_coverage_pct": "Coverage",
            "build_success_rate": "BuildSR", "deployment_frequency": "Deploy",
            "pr_cycle_time_hours": "CycleHrs", "on_call_incidents": "Incidents",
        }
        corr = self.r.correlations.rename(index=short, columns=short)
        mask = np.triu(np.ones_like(corr, dtype=bool))
        sns.heatmap(
            corr, mask=mask, cmap=sns.diverging_palette(240, 10, as_cmap=True),
            vmin=-1, vmax=1, ax=ax, linewidths=0.3, linecolor=_BG,
            annot=True, fmt=".2f", annot_kws={"size": 7},
            cbar_kws={"shrink": 0.7},
        )
        ax.set_title("Metric Correlation Matrix", fontweight="bold")
        ax.tick_params(axis="x", rotation=45, labelsize=7)
        ax.tick_params(axis="y", rotation=0,  labelsize=7)

    def _score_breakdown(self, ax):
        top   = self.r.summary.head(10)
        dims  = ["output_score", "quality_score", "collaboration_score",
                 "delivery_score", "reliability_score"]
        lbls  = ["Output", "Quality", "Collab", "Delivery", "Reliability"]
        cols  = ["#5B8CFF", "#2ECC71", "#F39C12", "#9B59B6", "#E74C3C"]
        wts   = [0.25, 0.30, 0.20, 0.15, 0.10]
        x     = np.arange(len(top))
        bot   = np.zeros(len(top))
        for dim, lbl, col, wt in zip(dims, lbls, cols, wts):
            vals = top[dim].values * wt
            ax.bar(x, vals, bottom=bot, color=col, label=lbl, edgecolor="none")
            bot += vals
        ax.set_xticks(x)
        ax.set_xticklabels(top["name"], rotation=35, ha="right", fontsize=7.5)
        ax.set_ylabel("Weighted Score Contribution")
        ax.set_title("Score Breakdown — Top 10 Developers", fontweight="bold")
        ax.legend(fontsize=7.5, ncol=5, loc="upper right")
        ax.grid(axis="y", alpha=0.3)

    def _trend_scatter(self, ax):
        t      = self.r.trends
        cmap   = {"Improving": "#2ECC71", "Stable": _ACCENT, "Declining": "#E74C3C"}
        colors = t["trend"].map(cmap)
        ax.scatter(t["slope_per_week"], t["r_squared"],
                   c=colors, s=55, alpha=0.85, edgecolors="none")
        ax.axvline(0, color=_FG, linewidth=0.8, linestyle="--", alpha=0.5)
        ax.set_xlabel("Slope (score/week)")
        ax.set_ylabel("R²")
        ax.set_title("Performance Trends", fontweight="bold")
        ax.grid(True, alpha=0.3)
        ax.legend(handles=[mpatches.Patch(color=c, label=l) for l, c in cmap.items()],
                  fontsize=7.5)

    def _anomaly_timeline(self, ax):
        anom = self.r.anomalies
        if anom.empty:
            ax.text(0.5, 0.5, "No anomalies detected", ha="center", va="center",
                    transform=ax.transAxes, color=_FG)
            ax.set_title("Anomaly Detection", fontweight="bold")
            return
        pos = anom[anom["anomaly_type"] == "Positive spike"]
        neg = anom[anom["anomaly_type"] == "Negative dip"]
        if not pos.empty:
            ax.scatter(pos["week_start"], pos["z_score"], color="#2ECC71",
                       s=60, label="Positive spike", alpha=0.85, zorder=5)
        if not neg.empty:
            ax.scatter(neg["week_start"], neg["z_score"], color="#E74C3C",
                       s=60, marker="v", label="Negative dip", alpha=0.85, zorder=5)
        ax.axhline(2.5, color=_ROSE, linestyle="--", linewidth=0.8, label="Threshold")
        ax.set_xlabel("Week")
        ax.set_ylabel("|Z-score|")
        ax.set_title("Anomaly Detection", fontweight="bold")
        ax.legend(fontsize=7.5)
        ax.grid(True, alpha=0.3)


# ═══════════════════════════════════════════════════════════════════════
# ── MODULE 5: REPORT EXPORTER ─────────────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════

class ReportExporter:
    """Exports analysis results to CSV and a structured plain-text report."""

    def __init__(self, results: AnalysisResults):
        self.r = results

    def export_csv(self, path: str = "reports/analysis_results.csv"):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.r.summary.to_csv(path, index=False)
        log.info(f"CSV report → {path}")

    def export_text_report(self, path: str = "reports/performance_report.txt"):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(self._build(), encoding="utf-8")
        log.info(f"Text report → {path}")

    def _build(self) -> str:
        r   = self.r
        m   = r.metadata
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        W   = 72

        def sep(char="═"): return char * W
        def h(title):      return f"\n{title}\n{'-' * W}"

        lines = [
            sep(), " SOFTWARE DEVELOPER PERFORMANCE ANALYSIS REPORT", sep(),
            f"  Generated  : {now}",
            f"  Dataset    : {m['data_path']}",
            f"  Developers : {m['n_developers']}",
            f"  Weeks      : {m['n_weeks']}  ({m['date_range'][0]} → {m['date_range'][1]})",
        ]

        # Band distribution
        bands = r.summary["performance_band"].value_counts()
        lines.append(h("PERFORMANCE BAND SUMMARY"))
        for band, count in bands.items():
            pct = count / len(r.summary) * 100
            lines.append(f"  {band:<12} {count:>3}  ({pct:4.1f}%)  {'█' * int(pct/3)}")

        # Top 10
        tm = r.trends.set_index("developer_id")["trend"].to_dict()
        lines.append(h("TOP 10 DEVELOPERS (Composite Score)"))
        lines.append(
            f"  {'#':<4} {'Name':<20} {'Role':<12} {'Team':<10}"
            f" {'Score':>7} {'Band':<12} {'Trend'}"
        )
        lines.append("-" * W)
        for i, (_, row) in enumerate(r.summary.head(10).iterrows(), 1):
            trend = tm.get(row["developer_id"], "—")
            lines.append(
                f"  {i:<4} {row['name']:<20} {row['role']:<12} {row['team']:<10}"
                f" {row['composite_score']:>7.2f} {row['performance_band']:<12} {trend}"
            )

        # Team summary
        lines.append(h("TEAM PERFORMANCE"))
        lines.append(
            f"  {'Team':<12} {'Devs':>5} {'Composite':>10}"
            f" {'Quality':>9} {'Collab':>8} {'Coverage':>9}"
        )
        lines.append("-" * W)
        for _, row in r.team_summary.iterrows():
            lines.append(
                f"  {row['team']:<12} {int(row['n_developers']):>5}"
                f" {row['avg_composite']:>10.2f} {row['avg_quality']:>9.2f}"
                f" {row['avg_collab']:>8.2f} {row['avg_coverage']:>9.1f}"
            )

        # Anomalies
        if not r.anomalies.empty:
            lines.append(h("ANOMALIES DETECTED"))
            for _, row in r.anomalies.head(10).iterrows():
                lines.append(
                    f"  {row['name']:<20} {str(row['week_start'])[:10]}"
                    f"  score={row['composite_score']:.1f}"
                    f"  z={row['z_score']:.2f}  [{row['anomaly_type']}]"
                )

        # Trends
        improving = r.trends[r.trends["trend"] == "Improving"].head(5)
        declining = r.trends[r.trends["trend"] == "Declining"].head(5)

        if not improving.empty:
            lines.append(h("IMPROVING DEVELOPERS"))
            for _, row in improving.iterrows():
                lines.append(
                    f"  {row['name']:<20} slope={row['slope_per_week']:+.4f}/wk"
                    f"  R²={row['r_squared']:.3f}"
                )

        if not declining.empty:
            lines.append(h("DECLINING DEVELOPERS  ⚠  Attention Needed"))
            for _, row in declining.iterrows():
                lines.append(
                    f"  {row['name']:<20} slope={row['slope_per_week']:+.4f}/wk"
                    f"  R²={row['r_squared']:.3f}"
                )

        lines += ["\n" + sep(), "END OF REPORT", sep()]
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════
# ── MODULE 6: CLI ─────────────────────────────────────────────────────
# ═══════════════════════════════════════════════════════════════════════

def cmd_generate(args):
    gen = DataGenerator(seed=args.seed)
    df  = gen.generate(n_developers=args.devs, n_weeks=args.weeks,
                       output_path=args.output)
    print(f"\n[✓] {len(df)} rows → {args.output}")


def cmd_analyze(args):
    engine  = PerformanceEngine(data_path=args.input)
    results = engine.run_full_analysis()

    print("\n=== DEVELOPER PERFORMANCE SUMMARY ===")
    cols = ["name", "role", "team", "composite_score", "performance_band",
            "quality_score", "collaboration_score", "percentile_rank"]
    print(results.summary[cols].to_string(index=False))

    if args.export:
        exp = ReportExporter(results)
        exp.export_csv("reports/analysis_results.csv")
        exp.export_text_report("reports/performance_report.txt")
        print("\n[✓] Reports written to reports/")


def cmd_visualize(args):
    engine  = PerformanceEngine(data_path=args.input)
    results = engine.run_full_analysis()
    dash    = Dashboard(results)
    dash.render(save_path=args.output, show=not args.no_show)
    print(f"[✓] Dashboard → {args.output}")


def cmd_full(args):
    """One command: generate → analyze → report → visualize."""
    print("── Step 1/3  Generating data ──────────────────────────────")
    gen = DataGenerator(seed=42)
    gen.generate(n_developers=args.devs, n_weeks=args.weeks,
                 output_path="data/sample_data.csv")

    print("── Step 2/3  Running analysis ─────────────────────────────")
    engine  = PerformanceEngine(data_path="data/sample_data.csv")
    results = engine.run_full_analysis()

    exp = ReportExporter(results)
    exp.export_csv("reports/analysis_results.csv")
    exp.export_text_report("reports/performance_report.txt")

    print("── Step 3/3  Rendering dashboard ──────────────────────────")
    dash = Dashboard(results)
    dash.render(save_path="visualizations/dashboard.png", show=not args.no_show)

    print("\n[✓] Pipeline complete.")
    print("    data/sample_data.csv")
    print("    reports/analysis_results.csv")
    print("    reports/performance_report.txt")
    print("    visualizations/dashboard.png")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="devperf",
        description="Software Developer Performance Analysis System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py generate  --devs 20 --weeks 52
  python main.py analyze   --input data/sample_data.csv --export
  python main.py visualize --input data/sample_data.csv
  python main.py full      --devs 20 --weeks 52
        """,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # generate
    p = sub.add_parser("generate", help="Generate synthetic developer data")
    p.add_argument("--devs",   type=int, default=10,                     help="Number of developers")
    p.add_argument("--weeks",  type=int, default=26,                     help="Number of weeks")
    p.add_argument("--seed",   type=int, default=42,                     help="Random seed")
    p.add_argument("--output", default="data/sample_data.csv",           help="Output CSV path")
    p.set_defaults(func=cmd_generate)

    # analyze
    p = sub.add_parser("analyze", help="Analyze a dataset CSV")
    p.add_argument("--input",  default="data/sample_data.csv")
    p.add_argument("--export", action="store_true", help="Save CSV + text reports")
    p.set_defaults(func=cmd_analyze)

    # visualize
    p = sub.add_parser("visualize", help="Render the 8-panel dashboard")
    p.add_argument("--input",    default="data/sample_data.csv")
    p.add_argument("--output",   default="visualizations/dashboard.png")
    p.add_argument("--no-show",  action="store_true", help="Don't open the plot window")
    p.set_defaults(func=cmd_visualize)

    # full pipeline
    p = sub.add_parser("full", help="Run full generate → analyze → visualize pipeline")
    p.add_argument("--devs",    type=int, default=10)
    p.add_argument("--weeks",   type=int, default=26)
    p.add_argument("--no-show", action="store_true")
    p.set_defaults(func=cmd_full)

    return parser


# ═══════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = build_parser()
    args   = parser.parse_args()
    args.func(args)
